package com.test.assesment.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UtilsTest {
    @Test
    public void testCalculateRewardPoint() {
        assertEquals(250, Utils.calculateRewardPoint(200l));

    }

}